from .suma import suma_num
from .resta import resta_num