def resta_num(a,b):
    resta = a - b
    return resta