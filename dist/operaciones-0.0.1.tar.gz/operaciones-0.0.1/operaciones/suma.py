def suma_num(a,b):
    suma = a + b
    return suma