# package_name

Description. 
The package operaciones is used to:
	- Add some numbers
	- Substract some numbers

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install package_name
```

## Usage

```python
from operaciones import suma
operaciones.suma_num()

from operaciones import resta
operaciones.resta_num()
```

## Author
Sabuat Urbina Ribeiro

## License
[MIT](https://choosealicense.com/licenses/mit/)